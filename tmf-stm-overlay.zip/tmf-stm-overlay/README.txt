TMF STM Overlay
===============
Shows STM, Super Gold / Silver / Bronze cutoffs and RTM for 401 tracks
(Nations, United, Puzzle, Stunt). Data is baked in from your stm-data.csv.

Run it (easiest)
  1. Start TrackMania.
  2. Run stm_overlay.exe.
  Play in Windowed or Borderless mode (a window overlay cannot draw on top of
  exclusive fullscreen).

Or load it into the game
  Put stm_overlay.asi in the game folder and use an ASI loader
  (e.g. Ultimate ASI Loader as binkw32.dll).

Keys (only while the game window is focused)
  F6 / F7           previous / next track
  Shift + F6 / F7   jump 10 tracks
  Ctrl + F6 / F7    jump to previous / next group (category / environment / difficulty)
  F8                toggle small HUD box
  F9                toggle track list panel

Notes
  - Track selection is manual. The overlay does not read the current track from the game.
  - Super Gold/Silver/Bronze cutoffs = STM + 1/8, 1/4, 1/2 of (RTM - STM), rounded up to the
    next 0.01. Inferred from your CSV; matches all 68,288 timed results.
  - Stunt tracks are scores: STM and RTM only, no cutoffs.
  - Not tested in-game (built on Linux with a 32-bit MinGW cross-compiler).

Rebuild
  i686-w64-mingw32-g++-posix -O2 -std=c++17 -static -mwindows -municode source/stm_overlay.cpp -o stm_overlay.exe -lgdi32 -luser32
  add -DBUILD_ASI -shared (and drop -mwindows -municode) for the .asi
