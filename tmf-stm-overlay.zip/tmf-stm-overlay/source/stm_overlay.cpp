// TMF STM Overlay
// Builds two ways from this one file:
//   stm_overlay.exe  - run it next to the game
//   stm_overlay.asi  - drop into the game folder with an ASI loader (or ModLoader-style injection)
// Shows STM / RTM / Super Gold / Super Silver / Super Bronze cutoffs for a selected track.
#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include "stm_data.h"

static const int N = (int)(sizeof(kTracks) / sizeof(kTracks[0]));

static HWND g_overlay = nullptr, g_game = nullptr;
static int g_sel = 0;
static bool g_hud = true, g_panel = false;

// ---------- formatting ----------
static std::wstring FmtTime(double s) {
    long cs = (long)std::llround(s * 100.0);
    wchar_t b[32];
    if (cs >= 6000) swprintf(b, 32, L"%ld:%02ld.%02ld", cs / 6000, (cs / 100) % 60, cs % 100);
    else swprintf(b, 32, L"%ld.%02ld", cs / 100, cs % 100);
    return b;
}
static double CeilCs(double s) { return std::ceil(s * 100.0 - 1e-6) / 100.0; }
static std::wstring W(const char* s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n);
    if (!w.empty()) w.pop_back();
    return w;
}
static std::wstring Label(const TrackRow& t) {
    std::wstring s = W(t.name);
    return s;
}
static std::wstring Sub(const TrackRow& t) {
    std::wstring s = W(t.cat);
    if (t.env[0]) s += L" / " + W(t.env);
    if (t.diff[0]) s += L" / " + W(t.diff);
    return s;
}

// ---------- game window ----------
static bool IsGameExe(DWORD pid) {
    HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!h) return false;
    wchar_t p[MAX_PATH]; DWORD n = MAX_PATH;
    bool ok = false;
    if (QueryFullProcessImageNameW(h, 0, p, &n)) {
        const wchar_t* base = wcsrchr(p, L'\\'); base = base ? base + 1 : p;
        ok = _wcsicmp(base, L"TmForever.exe") == 0 || _wcsicmp(base, L"TmNationsForever.exe") == 0;
    }
    CloseHandle(h);
    return ok;
}
static BOOL CALLBACK EnumCb(HWND h, LPARAM lp) {
    if (h == g_overlay || !IsWindowVisible(h) || GetWindow(h, GW_OWNER)) return TRUE;
    DWORD pid; GetWindowThreadProcessId(h, &pid);
    RECT r; GetClientRect(h, &r);
    if (r.right < 300 || r.bottom < 200) return TRUE;
    if (IsGameExe(pid)) { *(HWND*)lp = h; return FALSE; }
    return TRUE;
}

// ---------- drawing ----------
static void Line(HDC dc, int x, int& y, const std::wstring& s, COLORREF c, HFONT f, int lh) {
    SelectObject(dc, f); SetTextColor(dc, c);
    TextOutW(dc, x, y, s.c_str(), (int)s.size());
    y += lh;
}
static void Paint(HDC dc, RECT rc) {
    HBRUSH bg = CreateSolidBrush(RGB(14, 16, 22));
    FillRect(dc, &rc, bg); DeleteObject(bg);
    HBRUSH bd = CreateSolidBrush(RGB(255, 196, 0));
    FrameRect(dc, &rc, bd); DeleteObject(bd);
    SetBkMode(dc, TRANSPARENT);
    static HFONT fb = CreateFontW(20, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Consolas");
    static HFONT fr = CreateFontW(17, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Consolas");
    const TrackRow& t = kTracks[g_sel];
    int x = 12, y = 8;
    Line(dc, x, y, Label(t), RGB(255, 255, 255), fb, 24);
    Line(dc, x, y, Sub(t), RGB(150, 160, 180), fr, 22);
    auto fmt = [&](double v) { return t.isScore ? std::to_wstring((long)std::llround(v)) : FmtTime(v); };
    Line(dc, x, y, L"STM        " + fmt(t.stm), RGB(255, 196, 0), fb, 26);
    if (!t.isScore) {
        double g = t.rtm - t.stm;
        Line(dc, x, y, L"S.Gold     " + FmtTime(CeilCs(t.stm + g * 0.125)), RGB(255, 215, 90), fr, 20);
        Line(dc, x, y, L"S.Silver   " + FmtTime(CeilCs(t.stm + g * 0.25)), RGB(200, 205, 215), fr, 20);
        Line(dc, x, y, L"S.Bronze   " + FmtTime(CeilCs(t.stm + g * 0.5)), RGB(205, 140, 90), fr, 20);
        Line(dc, x, y, L"RTM        " + FmtTime(t.rtm), RGB(120, 200, 255), fr, 20);
    } else {
        Line(dc, x, y, L"RTM        " + fmt(t.rtm) + L"  (score)", RGB(120, 200, 255), fr, 20);
    }
    if (g_panel) {
        y += 6;
        Line(dc, x, y, L"-- tracks (F6/F7 move, Shift = 10, Ctrl = group) --", RGB(150, 160, 180), fr, 22);
        for (int i = g_sel - 6; i <= g_sel + 6; i++) {
            if (i < 0 || i >= N) { y += 19; continue; }
            const TrackRow& r = kTracks[i];
            std::wstring s = (i == g_sel ? L"> " : L"  ");
            std::wstring nm = W(r.name); nm.resize(16, L' ');
            s += nm + L" " + (r.isScore ? std::to_wstring((long)std::llround(r.stm)) : FmtTime(r.stm));
            Line(dc, x, y, s, i == g_sel ? RGB(255, 196, 0) : RGB(210, 214, 224), fr, 19);
        }
    }
}
static LRESULT CALLBACK Proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_PAINT) {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps);
        RECT rc; GetClientRect(h, &rc); Paint(dc, rc);
        EndPaint(h, &ps); return 0;
    }
    if (m == WM_NCHITTEST) return HTTRANSPARENT;
    return DefWindowProcW(h, m, w, l);
}

// ---------- input / update ----------
static bool Edge(int vk) {
    static bool prev[256] = {};
    bool d = (GetAsyncKeyState(vk) & 0x8000) != 0;
    bool e = d && !prev[vk]; prev[vk] = d; return e;
}
static void Move(int d, bool shift, bool ctrl) {
    if (ctrl) { // jump to next/prev group (category + environment + difficulty)
        auto same = [](int a, int b) { return !strcmp(kTracks[a].cat, kTracks[b].cat) && !strcmp(kTracks[a].env, kTracks[b].env) && !strcmp(kTracks[a].diff, kTracks[b].diff); };
        int i = g_sel;
        if (d > 0) { while (i < N - 1 && same(i, g_sel)) i++; }
        else { while (i > 0 && same(i, g_sel)) i--; int e = i; while (i > 0 && same(i - 1, e)) i--; }
        g_sel = i;
    } else g_sel += d * (shift ? 10 : 1);
    if (g_sel < 0) g_sel = 0;
    if (g_sel >= N) g_sel = N - 1;
}
static void Tick() {
    if (!g_game || !IsWindow(g_game)) { g_game = nullptr; EnumWindows(EnumCb, (LPARAM)&g_game); }
    bool fg = g_game && (GetForegroundWindow() == g_game || GetForegroundWindow() == g_overlay);
    if (fg) {
        bool sh = GetAsyncKeyState(VK_SHIFT) & 0x8000, ct = GetAsyncKeyState(VK_CONTROL) & 0x8000;
        if (Edge(VK_F6)) Move(-1, sh, ct);
        if (Edge(VK_F7)) Move(+1, sh, ct);
        if (Edge(VK_F8)) g_hud = !g_hud;
        if (Edge(VK_F9)) g_panel = !g_panel;
    }
    if (!fg || !(g_hud || g_panel)) { ShowWindow(g_overlay, SW_HIDE); return; }
    int w = 320, h = g_panel ? 130 + 13 * 19 + 40 : 150;
    POINT p = {0, 0}; ClientToScreen(g_game, &p);
    RECT cr; GetClientRect(g_game, &cr);
    SetWindowPos(g_overlay, HWND_TOPMOST, p.x + cr.right - w - 16, p.y + 16, w, h, SWP_NOACTIVATE | SWP_SHOWWINDOW);
    InvalidateRect(g_overlay, nullptr, TRUE);
}

static DWORD WINAPI Run(LPVOID) {
    HINSTANCE hi = GetModuleHandleW(nullptr);
    WNDCLASSW wc = {}; wc.lpfnWndProc = Proc; wc.hInstance = hi; wc.lpszClassName = L"TmfStmOverlay";
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassW(&wc);
    g_overlay = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
        wc.lpszClassName, L"STM", WS_POPUP, 0, 0, 320, 150, nullptr, nullptr, hi, nullptr);
    SetLayeredWindowAttributes(g_overlay, 0, 225, LWA_ALPHA);
    SetTimer(g_overlay, 1, 50, nullptr);
    MSG m;
    while (GetMessageW(&m, nullptr, 0, 0) > 0) {
        if (m.message == WM_TIMER) Tick();
        TranslateMessage(&m); DispatchMessageW(&m);
    }
    return 0;
}

#ifdef BUILD_ASI
BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        CreateThread(nullptr, 0, Run, nullptr, 0, nullptr);
    }
    return TRUE;
}
#else
int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) { return (int)Run(nullptr); }
#endif
